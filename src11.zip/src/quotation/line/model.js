const logger = require("../../api/logger");


module.exports = (sequelize, DataTypes) => {
    const QuotationLine = sequelize.define('quotationLine', {
        quantity: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: 1,
        },
        unitRate: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: 1,
        },
        exchangeRate: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: 1,
        },
        price: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: 0,
        },
        discount: {
            type: DataTypes.DOUBLE,
            defaultValue: 0,
        },
        total: {
            type: DataTypes.DOUBLE,
            defaultValue: 0,
        },

        isActive: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true,
        },
    }, {
        sequelize,
        // don't forget to enable timestamps!
        timestamps: true,
        // I don't want createdAt
        createdAt: true,
        // I want updatedAt to actually be called updateTimestamp
        updatedAt: 'updateTimestamp',
        // disable the modification of tablenames; By default, sequelize will automatically
        // transform all passed model names (first parameter of define) into plural.
        // if you don't want that, set the following
        freezeTableName: true,
    })
    QuotationLine.associate = models => {
        logger.info('Associating table QuotationLine with models');

        // QuotationLine associations
        
        if (models.currency) {
            QuotationLine.belongsTo(models.currency, {
                foreignKey: 'itemCurrencyId',
                as: 'itemCurrency'
            });
        }
    };

    return QuotationLine;
};

// 1. STRING: A variable length string.
// 2. CHAR: A fixed length string.
// 3. TEXT: A long string.
// 4. INTEGER: A 32-bit integer.
// 5. BIGINT: A 64-bit integer.
// 6. FLOAT: A floating point number.
// 7. DOUBLE: A double floating point number.
// 8. DECIMAL: A fixed-point decimal number.
// 9. BOOLEAN: A boolean value.
// 10. DATE: A date object.
// 11. DATEONLY: A date object without time.
// 12. TIME: A time object.
// 13. UUID: A universally unique identifier.
// 14. ENUM: A value from a predefined list of values.
// 15. ARRAY: An array of values.
// 16. JSON: A JSON object.
// 17. JSONB: A JSON object stored as a binary format.