

const {validateToken} = require("../api/jwtApi")
const controller = require("./controller")
const service = require("./service")
const express = require("express")
const router = express.Router()
router.use(validateToken)

router
.post("/create", controller.createCustomer)
.post("/change-password", controller.changePassword)
.post("/reset-password", controller.resetPassword)
.post("/linkterminal/:id", controller.linkTerminal)
.post("/unlinkterminal/:id", controller.unlinkTerminal)
.put("/update/:id", controller.updateCustomer)
.put("/deactivate/:id", controller.deactivateCustomer)
.post("/deactivate-account", controller.deactivateOwnAccount)
.put("/deactivate-account", controller.deactivateOwnAccount)
.delete("/delete-account", controller.deleteOwnAccount)
.delete("/find/:id", controller.deleteCustomer)
.get("/find", controller.getCustomers)
.get("/find/:id", controller.getCustomerById)

module.exports = router