module.exports = (sequelize, DataTypes) => {
    const Currency = sequelize.define('currency', {
        code: {
            type: DataTypes.STRING,
            allowNull: false,
            // defaultValue: 1,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            // defaultValue: 1,
        },
        rate: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: 1,
        },
        isActive: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true,
        },
        isLocalCCY: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false,
        },
        exchangeDirection: {
            type: DataTypes.ENUM('local_to_foreign', 'foreign_to_local'),
            allowNull: false,
            defaultValue: 'local_to_foreign',
            comment: 'Direction of exchange rate: local_to_foreign (LAK to Foreign) or foreign_to_local (Foreign to LAK)'
        },
        symbol: {
            type: DataTypes.STRING(10),
            allowNull: true,
            comment: 'Currency symbol (e.g., $, £, ₭)'
        },
    }, {
        sequelize,
        // don't forget to enable timestamps!
        timestamps: true,
        // I don't want createdAt
        createdAt: true,
        // I want updatedAt to actually be called updateTimestamp
        updatedAt: 'updateTimestamp',
        // disable the modification of tablenames; By default, sequelize will automatically
        // transform all passed model names (first parameter of define) into plural.
        // if you don't want that, set the following
        freezeTableName: true,
        hooks: {
            // After create, save the new record to audit table
            afterCreate: async (currency, options) => {
                try {
                    const AuditModel = sequelize.models.CurrencyAudit;
                    if (!AuditModel || typeof AuditModel.createAuditRecord !== 'function') return;

                    const userId = options.context?.userId || 1;
                    const reason = options.context?.reason || 'Currency created';

                    await AuditModel.createAuditRecord(
                        currency.toJSON(),
                        userId,
                        'CREATE',
                        reason,
                        options.transaction
                    );
                } catch (error) {
                    console.error('Failed to create audit record after currency create:', error);
                }
            },

            // Before update, save current state to audit table
            beforeUpdate: async (currency, options) => {
                try {
                    const AuditModel = sequelize.models.CurrencyAudit;
                    if (!AuditModel || typeof AuditModel.createAuditRecord !== 'function') return;

                    // Fetch current state before update
                    const currentRecord = await sequelize.models.currency.findByPk(currency.id, {
                        transaction: options.transaction
                    });

                    if (currentRecord) {
                        const userId = options.context?.userId || 1;
                        const reason = options.context?.reason || 'Currency updated';

                        await AuditModel.createAuditRecord(
                            currentRecord.toJSON(),
                            userId,
                            'UPDATE',
                            reason,
                            options.transaction
                        );
                    }
                } catch (error) {
                    console.error('Failed to create audit record before currency update:', error);
                }
            },

            // Before delete, save the record being deleted
            beforeDestroy: async (currency, options) => {
                try {
                    const AuditModel = sequelize.models.CurrencyAudit;
                    if (!AuditModel || typeof AuditModel.createAuditRecord !== 'function') return;

                    const userId = options.context?.userId || 1;
                    const reason = options.context?.reason || 'Currency deleted';

                    await AuditModel.createAuditRecord(
                        currency.toJSON(),
                        userId,
                        'DELETE',
                        reason,
                        options.transaction
                    );
                } catch (error) {
                    console.error('Failed to create audit record before currency delete:', error);
                }
            }
        }
    })

    Currency.associate = models => {
        // Audit Trail association
        Currency.hasMany(models.currencyAudit, {
            foreignKey: 'currencyId',
            as: 'auditTrail',
        });
    };

    return Currency;
};

// 1. STRING: A variable length string.
// 2. CHAR: A fixed length string.
// 3. TEXT: A long string.
// 4. INTEGER: A 32-bit integer.
// 5. BIGINT: A 64-bit integer.
// 6. FLOAT: A floating point number.
// 7. DOUBLE: A double floating point number.
// 8. DECIMAL: A fixed-point decimal number.
// 9. BOOLEAN: A boolean value.
// 10. DATE: A date object.
// 11. DATEONLY: A date object without time.
// 12. TIME: A time object.
// 13. UUID: A universally unique identifier.
// 14. ENUM: A value from a predefined list of values.
// 15. ARRAY: An array of values.
// 16. JSON: A JSON object.
// 17. JSONB: A JSON object stored as a binary format.