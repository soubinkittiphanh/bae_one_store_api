const orderRouter = require("./orderRouter")
const dymCustomerRouter = require("./dymCustomerRouter")
const reportRouter = require("./reportRouter")
const generalLedger = require("../GL").router
const chartAccount = require("../account").router
const upgrade = require("./upgrade")
const rider = require("../rider").router
const location = require("../location").router
const campaign = require("../controllers/admin/campaign").router
const campaignEntry = require("../controllers/admin/campaign/entry").router
const card = require("../card").router
const paymentHeadAP = require("../payment/header").router
const receiveHeadAR = require("../income").router
const poheader = require("../purchasing").router
const poLine = require("../purchasing/line").router
const currency = require("../currency").router
const geography = require("../geography").router
const customer = require("../dynamicCustomer").router
const category = require("../category").router
const mainCategory = require("../mainCategory").router
const client = require("../client").router
const unit = require("../unit").router
const paymentMethod = require("../paymentMethod").router
const sale = require("../sales").router
const salePayment = require("../salePayment").router
const menuHeader = require("../menu").router
const menuLine = require("../menu/line").router
const product = require("../product").router
const productTemp = require("../productTemp").router
const saleLine = require("../sales/line").router
const quotation = require("../quotation").router
const quotationLine = require("../quotation/line").router
const transfer = require("../transfer").router
const terminal = require("../terminal").router
const user = require("../user").router
const shipping = require("../shipping").router
const shippingOrder = require("../shippingOrder").router
const company = require("../company").router
const tutorial = require("../tutorial").router
const group = require("../group").router
const authority = require("../authority").router
const account = require("../account").router
const priceList = require("../priceList").router
const order = require("../order").router
const vendor = require("../vendor").router
const reservation = require("../reservation").router
const receiving = require("../receiving").router
const receivingLine = require("../receiving/line").router
const spf = require("../spf").router
const webProductGroup = require("../web_product_group").router
const service = require("../service").router
const washJob = require("../carcare/washJob").router
const table = require("../pos/table").router
const ticket = require("../pos/ticket").router
const ticketLine = require("../pos/ticketLine").router
const tax = require("../tax/router")
const transaction = require("../transaction/router")
const moneyAdvance = require("../PWT/moneyAdvance/router")
const moneyAdvanceReport = require("../PWT/moneyAdvanceReport/router")
const moneySettlement = require("../PWT/moneySettlement/router")
const accountStatement = require("../PWT/accountStatement/router")
const project = require("../PWT/project/router")
const projectContract = require("../PWT/projectContract/router")
const projectInvoice = require("../PWT/projectInvoice/router")
const withdrawalApplication = require("../PWT/withdrawalApplication/router")
const bank = require("../bank/router")
const bankAccount = require("../bankAccount/router")
const ministry = require("../ministry/router")
const revenueTarget = require("../revenueTarget/router")
const apInvoice = require("../AP/invoice/router")
const apInvoiceLine = require("../AP/invoiceLine/router")
const apInvoiceSettlement = require("../AP/invoiceSettlement/router")
const apInvoiceSettlementLine = require("../AP/invoiceSettlementLine/router")
const applicant = require("../job-fair/applicant/router")
const MOU = require("../job-fair/MOU/router")
const agency = require("../job-fair/agency/router")
const jobAdvertise = require("../job-fair/jobDescription/router")
const benefit = require("../benefit/router")
const arInvoiceHeader = require("../AR/invoice/header/router")
const arInvoiceLine = require("../AR/invoice/line/router")
const arReceiveHeader = require("../AR/receive/header/router")
const arReceiveLine = require("../AR/receive/line/router")
const batchJob = require("../job-fair/job-batch/router")
const userRole = require("../userRole/router")
const recipe = require("../recipe/router")
const promotions = require("../pos/promotion/router")
const memberOffer = require("../member_offer/router")
const stockTransaction = require("../stockTransaction/router")
const qrRouter = require("../QRRequest/router")
const size = require("../size/router")
const color = require("../color/router")
const printer = require("../printer/router")
const student = require("../student/router")
const nfcCard = require("../nfcCard/router")
const transactionEntry = require("../transactionEntry/router")
const accountDailyBalance = require("../accountDailyBalance/router")
const schoolAcademicYear = require("../school/academicYear/router")
const schoolClass = require("../school/class/router")
const schoolRoom = require("../school/room/router")
const schoolFeeItem = require("../school/feeItem/router")
const schoolFeeStructure = require("../school/feeStructure/router")
const schoolInvoice = require("../school/invoice/router")
const schoolPayment = require("../school/payment/router")
const schoolReport = require("../school/report/router")
const schoolShift = require("../school/shift/router")
const businessDate = require("../businessDate/router")
const databaseBackup = require("../databaseBackup/router")
const loyalty = require("../loyalty/router")
const fixedAsset = require("../fixedAsset").router

// Microfinance routers
const mfCif = require("../microfinance/cif").router
const mfGroups = require("../microfinance/groups").router
const mfCollateral = require("../microfinance/collateral").router
const mfProducts = require("../microfinance/products").router
const mfAccounts = require("../microfinance/accounts").router
const mfJournal = require("../microfinance/journal").router
const mfBatch = require("../microfinance/batch").router
const productOptionGroup = require("../productOptionGroup").router
const productOption = require("../productOption").router

module.exports = {
    orderRouter,
    dymCustomerRouter,
    reportRouter,
    generalLedger,
    chartAccount,
    upgrade,
    rider,
    campaign,
    campaignEntry,
    card,
    paymentHeadAP,
    receiveHeadAR,
    currency,
    poheader,
    poLine,
    geography,
    customer,
    category,
    client,
    unit,
    paymentMethod,
    sale,
    saleLine,
    product,
    quotation,
    quotationLine,
    location,
    transfer,
    terminal,
    user,
    shipping,
    shippingOrder,
    company,
    tutorial,
    group,
    authority,
    account,
    priceList,
    order,
    vendor,
    menuHeader,
    menuLine,
    reservation,
    receiving,
    receivingLine,
    webProductGroup,
    spf,
    service,
    table,
    ticket,
    ticketLine,
    washJob,
    moneyAdvance,
    moneyAdvanceReport,
    moneySettlement,
    project,
    projectContract,
    projectInvoice,
    withdrawalApplication,
    tax,
    bankAccount,
    ministry,
    revenueTarget,
    apInvoice,
    apInvoiceLine,
    apInvoiceSettlement,
    apInvoiceSettlementLine,
    applicant,
    jobAdvertise,
    benefit,
    arInvoiceHeader,
    arInvoiceLine,
    arReceiveHeader,
    arReceiveLine,
    batchJob,
    agency,
    MOU,
    userRole,
    transaction,
    memberOffer,
    recipe,
    promotions,
    stockTransaction,
    salePayment,
    productTemp,
    accountStatement,
    qrRouter,
    size,
    color,
    bank,
    printer,
    student,
    nfcCard,
    transactionEntry,
    mainCategory,
    accountDailyBalance,
    schoolAcademicYear,
    schoolClass,
    schoolRoom,
    schoolFeeItem,
    schoolFeeStructure,
    schoolInvoice,
    schoolPayment,
    schoolReport,
    schoolShift,
    businessDate,
    databaseBackup,
    loyalty,
    fixedAsset,
    mfCif,
    mfGroups,
    mfCollateral,
    mfProducts,
    mfAccounts,
    mfJournal,
    mfBatch,
    productOptionGroup,
    productOption
}