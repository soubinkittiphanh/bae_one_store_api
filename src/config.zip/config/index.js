const env = require("./env")
module.exports =env;