const jwtApi =  require("./jwtApi")
module.exports = {
    jwtApi,
}